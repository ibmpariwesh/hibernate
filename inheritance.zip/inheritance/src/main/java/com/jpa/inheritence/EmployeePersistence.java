package com.jpa.inheritence;

import javax.persistence.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.jpa.inheritence.*;

public class EmployeePersistence {

	public static void main(String[] args) {

		StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
		
		SessionFactory sessionFactory  = metadata.getSessionFactoryBuilder().build();
		Session session = sessionFactory.openSession();
		
		session.beginTransaction();

		ActiveEmployee ae1 = new ActiveEmployee(101, "Karun", 10000, 5);
		ActiveEmployee ae2 = new ActiveEmployee(102, "Rishab", 12000, 7);

		RetiredEmployee re1 = new RetiredEmployee(103, "Ramesh", 5000);
		RetiredEmployee re2 = new RetiredEmployee(104, "Raj", 4000);

		session.persist(ae1);
		session.persist(ae2);

		session.persist(re1);
		session.persist(re2);

		session.getTransaction().commit();

		session.close();

	}
}